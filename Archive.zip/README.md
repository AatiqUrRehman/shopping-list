## React + Redux + TypeScript Cart App

## Setup

```
npm install

npm run start

```
